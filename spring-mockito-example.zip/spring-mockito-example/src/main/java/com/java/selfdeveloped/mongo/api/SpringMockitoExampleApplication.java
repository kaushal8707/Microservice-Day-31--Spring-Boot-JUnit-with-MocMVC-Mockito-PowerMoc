package com.java.selfdeveloped.mongo.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMockitoExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMockitoExampleApplication.class, args);
	}

}
