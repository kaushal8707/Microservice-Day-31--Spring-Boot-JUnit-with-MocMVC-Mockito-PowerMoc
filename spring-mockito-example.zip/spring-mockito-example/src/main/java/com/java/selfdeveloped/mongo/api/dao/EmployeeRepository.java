package com.java.selfdeveloped.mongo.api.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.java.selfdeveloped.mongo.api.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}