//package com.java.selfdeveloped.mongo.api;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.scheduling.annotation.Scheduled;
//
//@Configuration
//public class Test {
//
//	int counter =0;
//	@Scheduled(fixedDelay = 1000, initialDelay = 1000)
//	public void scheduleFixedRateWithInitialDelayTask() {
//	 
//	    long now = System.currentTimeMillis() / 1000;
//	    counter++;
//	    System.out.println(
//	      "Fixed rate task with one second initial delay - " + now);
//	    if(counter>2) {
//	    	System.out.println("Not Received");
//	    }
//	}
//}
//
